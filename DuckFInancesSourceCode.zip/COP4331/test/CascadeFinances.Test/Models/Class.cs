﻿using System;
using Xunit;

namespace CascadeFinances.Test.Models
{
    public class Class
    {
        [Fact]
        public void Test()
        {

        }
    }
}
